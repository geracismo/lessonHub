package com.example.lessonhub.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.lessonhub.R;
import com.example.lessonhub.model.Professor;

import java.util.List;

public class ProfessorSpinnerAdapter extends BaseAdapter {
    public Context context = null;
    public List<Professor> list = null;

    public ProfessorSpinnerAdapter(@NonNull Context context, List<Professor> list) {
        this.context = context;
        this.list = list;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Professor getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.spinner_row, null);

        Professor p = (Professor) getItem(position);
        TextView row = view.findViewById(R.id.spinner_row);

        if(p.getId() != -1) {
            row.setText((getItem(position)).getName() + " " + (getItem(position)).getSurname());
        } else
            row.setText("");

        return view;
    }
}
