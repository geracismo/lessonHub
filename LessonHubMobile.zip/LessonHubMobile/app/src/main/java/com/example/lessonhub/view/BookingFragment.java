package com.example.lessonhub.view;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lessonhub.R;
import com.example.lessonhub.Session;
import com.example.lessonhub.controller.MainActivity;
import com.example.lessonhub.model.Booking;
import com.google.android.material.bottomappbar.BottomAppBar;

import java.util.ArrayList;
import java.util.List;

public class BookingFragment extends Fragment {

    public String TAG = "booking";

    MainActivity parent;

    public ListView bookingList;

    public Spinner courseSpinner;

    public Spinner professorSpinner;

    public Spinner daySpinner;

    public Dialog dialog;

    public Button reserve;

    public Button search;


    public BookingFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.search_repetition, container, false);
        this.courseSpinner = view.findViewById(R.id.course_spinner);
        this.bookingList = view.findViewById(R.id.list_possible_res);
        this.professorSpinner = view.findViewById(R.id.professor_spinner);
        this.reserve = view.findViewById(R.id.reserve_btn);
        this.search = view.findViewById(R.id.search);
        this.dialog = new Dialog(parent);

        this.reserve.setOnClickListener((View.OnClickListener) parent);
        this.search.setOnClickListener((View.OnClickListener) parent);

        this.bookingList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        if(parent.session.mainUser == null) {
            reserve.setEnabled(false);
        } else {
            reserve.setEnabled(true);
        }

        return view;
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        parent = (MainActivity) context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        parent.onFragmentViewCreated(this);
    }

    public static BookingFragment newInstance() {
        BookingFragment fragment = new BookingFragment();
        return fragment;
    }

    public void createDialog() {
        this.dialog.setCancelable(true);
        this.dialog.setContentView(R.layout.popup_confirmation);

        Button si = dialog.findViewById(R.id.confirm_popup);
        Button no = dialog.findViewById(R.id.denied);

        si.setOnClickListener(parent);
        no.setOnClickListener(parent);
    }

}
