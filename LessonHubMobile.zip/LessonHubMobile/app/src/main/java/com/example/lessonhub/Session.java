package com.example.lessonhub;

import android.app.Application;

import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lessonhub.controller.MainActivity;
import com.example.lessonhub.model.Booking;
import com.example.lessonhub.model.Course;
import com.example.lessonhub.model.Professor;
import com.example.lessonhub.model.Slot;
import com.example.lessonhub.model.Teaching;
import com.example.lessonhub.model.User;
import com.example.lessonhub.view.Adapter;
import com.example.lessonhub.view.CourseSpinnerAdapter;
import com.example.lessonhub.view.ProfessorSpinnerAdapter;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

public class Session extends Application {

    public User mainUser;

    public String psw;

    public String url = "http://192.168.1.229:8080/TWEB/ServletBooking";

    public Gson gson = new Gson();

    public RequestQueue queue;

    MainActivity activity;

    public Session(MainActivity activity) {
        this.activity = activity;
        queue = Volley.newRequestQueue(this.activity);
        queue.start();
    }

    public void onLogout(String username, String password) {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization.addProperty("email", username);
        authorization.addProperty("password", password);

        jo.addProperty("type", "logout");
        jo.add("params", null);
        jo.add("authorization", authorization);


        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                    Toast.makeText(activity, "Disconesso con successo!", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity, "Server error!", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void onLogin(String username, String password) {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization.addProperty("email", username);
        authorization.addProperty("password", password);

        jo.addProperty("type", "login");
        jo.add("params", null);
        jo.add("authorization", authorization);


        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonObject user = obj.get("response").getAsJsonObject();
                    User mainUser = new User(user.get("username").getAsString(), user.get("name").getAsString(), user.get("surname").getAsString(), user.get("role").getAsInt(), user.get("mfx").getAsString().charAt(0));
                    setMainUser(mainUser);
                    setPreferences(mainUser, password, mainUser.getName(), mainUser.getSurname(), mainUser.getRole(), String.valueOf(mainUser.getMfx()));
                    activity.showFragment(activity.homeFragment);
                    activity.homeFragment.welcome.setText(mainUser.getUsername());

                    Toast.makeText(activity, "Benvenuto!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "Username o psw errate!", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity, "Server error!" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void onLoadHistory() {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization = setAuthorization(authorization);

        jo.addProperty("type", "user_show_history");
        jo.add("params", null);
        jo.add("authorization", authorization);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                List<Booking> list = new ArrayList<>();
                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonArray array = obj.get("response").getAsJsonObject().get("data").getAsJsonArray();

                    for(JsonElement row : array) {
                        int techingid = row.getAsJsonObject().get("teaching").getAsInt();

                        int slot = Slot.generateSlotNumber(row.getAsJsonObject().get("slot").getAsJsonObject().get("day").getAsInt(),
                                row.getAsJsonObject().get("slot").getAsJsonObject().get("hour").getAsInt());

                        Course course = new Course(row.getAsJsonObject().get("course").getAsJsonObject().get("id").getAsInt(),
                                row.getAsJsonObject().get("course").getAsJsonObject().get("name").getAsString());

                        Professor prof = new Professor(row.getAsJsonObject().get("professor").getAsJsonObject().get("id").getAsInt(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("name").getAsString(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("surname").getAsString(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("mfx").getAsString().charAt(0),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("active").getAsBoolean());

                        int status = row.getAsJsonObject().get("status").getAsInt();

                        Teaching teach = new Teaching(techingid, prof, course, true);

                        Booking book = new Booking(mainUser.getUsername(), teach, slot,status);

                        list.add(book);
                    }

                    activity.historyFragment.history.setAdapter(new Adapter(activity, list, activity.historyFragment.TAG));

                } else {
                    Toast.makeText(activity, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", error.toString());
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void onLoadReservation() {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization = setAuthorization(authorization);

        jo.addProperty("type", "show_my_reservations");
        jo.add("params", null);
        jo.add("authorization", authorization);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                List<Booking> list = new ArrayList<>();

                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonArray array = obj.get("response").getAsJsonObject().get("data").getAsJsonArray();

                    for(JsonElement row : array) {
                        int techingid = row.getAsJsonObject().get("teaching").getAsInt();

                        int slot = Slot.generateSlotNumber(row.getAsJsonObject().get("slot").getAsJsonObject().get("day").getAsInt(),
                                row.getAsJsonObject().get("slot").getAsJsonObject().get("hour").getAsInt());

                        Course course = new Course(row.getAsJsonObject().get("course").getAsJsonObject().get("id").getAsInt(),
                                row.getAsJsonObject().get("course").getAsJsonObject().get("name").getAsString());

                        Professor prof = new Professor(row.getAsJsonObject().get("professor").getAsJsonObject().get("id").getAsInt(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("name").getAsString(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("surname").getAsString(),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("mfx").getAsString().charAt(0),
                                row.getAsJsonObject().get("professor").getAsJsonObject().get("active").getAsBoolean());

                        int status = row.getAsJsonObject().get("status").getAsInt();

                        Teaching teach = new Teaching(techingid, prof, course, true);

                        Booking book = new Booking(mainUser.getUsername(), teach, slot,status);

                        list.add(book);
                    }

                    activity.reservationFragment.reservationList.setAdapter(new Adapter(activity, list, activity.reservationFragment.TAG));

                } else {
                    Toast.makeText(activity, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", error.toString());
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void setMainUser(User user) {
        this.mainUser = user;
    }

    public void onLoadPossibleBooking() {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization = setAuthorization(authorization);

        jo.addProperty("type", "show_available_reservations");
        jo.add("params", null);
        jo.add("authorization", authorization);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                List<Booking> list = new ArrayList<>();

                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonArray array = obj.get("response").getAsJsonArray();

                    for(JsonElement row : array) {
                        int techingid = row.getAsJsonObject().get("teaching_id").getAsInt();

                        int slot = Slot.generateSlotNumber(Integer.parseInt(row.getAsJsonObject().get("slot").getAsString().split(";")[0].split(" ")[1]),
                                Integer.parseInt(row.getAsJsonObject().get("slot").getAsString().split(";")[1].split(" ")[1].split(":")[0]));

                        Course course = new Course(row.getAsJsonObject().get("course_id").getAsInt(),
                                row.getAsJsonObject().get("course_name").getAsString());

                        Professor prof = new Professor(row.getAsJsonObject().get("professor_id").getAsInt(),
                                row.getAsJsonObject().get("name").getAsString(), row.getAsJsonObject().get("surname").getAsString(),
                                row.getAsJsonObject().get("mfx").getAsString().charAt(0), true);

                        Teaching teach = new Teaching(techingid, prof, course, true);

                        Booking book;

                        if(mainUser == null)
                            book = new Booking(null, teach, slot,0);
                        else
                            book = new Booking(mainUser.getUsername(), teach, slot,0);


                        list.add(book);
                    }

                    activity.bookingFragment.bookingList.setAdapter(new Adapter(activity, list, activity.bookingFragment.TAG));

                } else {
                    Toast.makeText(activity, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", error.toString());
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void onLoadCourses() {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization = setAuthorization(authorization);

        jo.addProperty("type", "get_courses");
        jo.add("params", null);
        jo.add("authorization", authorization);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                List<Course> list = new ArrayList<>();
                list.add(new Course(-1, "-1"));

                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonArray array = obj.get("response").getAsJsonObject().get("data").getAsJsonArray();

                    for(JsonElement row : array) {
                        int id = row.getAsJsonObject().get("id").getAsInt();

                        String name = row.getAsJsonObject().get("name").getAsString();

                        Course course = new Course(id, name);

                        list.add(course);
                    }

                    activity.bookingFragment.courseSpinner.setAdapter(new CourseSpinnerAdapter(activity, list));

                } else {
                    Toast.makeText(activity, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", error.toString());
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    public void onLoadProfessor() {
        JsonObject jo = new JsonObject();
        JsonObject authorization = new JsonObject();

        authorization = setAuthorization(authorization);

        jo.addProperty("type", "get_professors");
        jo.add("params", null);
        jo.add("authorization", authorization);

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                List<Professor> list = new ArrayList<>();
                list.add(new Professor(-1, "", "", 'v',true));
                Log.d("RESPONSE", response);

                JsonObject obj = gson.fromJson(response, JsonObject.class);
                boolean error = obj.get("error").getAsBoolean();

                if(!error) {
                    JsonArray array = obj.get("response").getAsJsonObject().get("data").getAsJsonArray();

                    for(JsonElement row : array) {
                        int id = row.getAsJsonObject().get("id").getAsInt();

                        String name = row.getAsJsonObject().get("name").getAsString();

                        String surname = row.getAsJsonObject().get("surname").getAsString();

                        char mfx = row.getAsJsonObject().get("mfx").getAsString().charAt(0);

                        boolean active = row.getAsJsonObject().get("active").getAsBoolean();

                        Professor prof = new Professor(id, name, surname, mfx,active);

                        list.add(prof);
                    }

                    activity.bookingFragment.professorSpinner.setAdapter(new ProfessorSpinnerAdapter(activity, list));

                } else {
                    Toast.makeText(activity, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR", error.toString());
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return jo.toString().getBytes();
            }
        };

        queue.add(request);
    }

    private JsonObject setAuthorization(JsonObject authorization) {
        if(mainUser == null) {
            authorization.add("email", null);
            authorization.add("password", null);
        } else  {
            authorization.addProperty("email", this.mainUser.getUsername());
            authorization.addProperty("password", this.psw);
        }
        return authorization;
    }

    public void onBookReserve(List<Booking> list) {

        for(Booking book : list) {

            JsonObject jo = new JsonObject();
            JsonObject authorization = new JsonObject();
            JsonObject mode = new JsonObject();
            JsonObject elem = new JsonObject();
            JsonObject reservation = new JsonObject();
            JsonObject slot = new JsonObject();
            JsonObject data = new JsonObject();

            slot.addProperty("day", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[0].split(" ")[1]));
            slot.addProperty("hour", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[1].split(":")[0].split(" ")[1]));

            reservation.addProperty("teaching", book.getTeaching().getId());
            reservation.add("slot", slot);

            elem.add("reservation", reservation);

            data.add("elem", elem);

            authorization.addProperty("email", this.mainUser.getUsername());
            authorization.addProperty("password", this.psw);

            jo.addProperty("type", "book_reservation");
            jo.add("params", null);
            jo.add("data", data);
            jo.add("authorization", authorization);
            Log.d("DONE", jo.toString());


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    JsonObject obj = gson.fromJson(response, JsonObject.class);
                    boolean error = obj.get("error").getAsBoolean();

                    if(!error) {
                        Toast.makeText(activity, "Reservation booked.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(activity, "Error.", Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d("ERROR", error.toString());
                }
            }) {
                @Override
                public byte[] getBody() throws AuthFailureError {
                    return jo.toString().getBytes();
                }
            };

            queue.add(request);
        }
    }

    public void onCancelReservation(List<Booking> list) {

        for(Booking book : list) {
            JsonObject jo = new JsonObject();
            JsonObject authorization = new JsonObject();
            JsonObject mode = new JsonObject();
            JsonObject elem = new JsonObject();
            JsonObject reservation = new JsonObject();
            JsonObject slot = new JsonObject();
            JsonObject data = new JsonObject();

            slot.addProperty("day", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[0].split(" ")[1]));
            slot.addProperty("hour", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[1].split(":")[0].split(" ")[1]));

            mode.addProperty("mode", 1);

            reservation.addProperty("teaching", book.getTeaching().getId());
            reservation.add("slot", slot);

            elem.add("reservation", reservation);

            data.add("elem", elem);

            authorization.addProperty("email", this.mainUser.getUsername());
            authorization.addProperty("password", this.psw);

            jo.addProperty("type", "delete_done_reservation");
            jo.add("params", mode);
            jo.add("data", data);
            jo.add("authorization", authorization);
            Log.d("DONE", jo.toString());


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    JsonObject obj = gson.fromJson(response, JsonObject.class);
                    boolean error = obj.get("error").getAsBoolean();

                    if(!error) {
                        Toast.makeText(activity, "Reservation canceled.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(activity, "Error.", Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d("ERROR", error.toString());
                }
            }) {
                @Override
                public byte[] getBody() throws AuthFailureError {
                    return jo.toString().getBytes();
                }
            };

            queue.add(request);

        }

    }

    public void onDoneReservation(List<Booking> list) {

        for(Booking book : list) {
            JsonObject jo = new JsonObject();
            JsonObject authorization = new JsonObject();
            JsonObject mode = new JsonObject();
            JsonObject elem = new JsonObject();
            JsonObject reservation = new JsonObject();
            JsonObject slot = new JsonObject();
            JsonObject data = new JsonObject();

            slot.addProperty("day", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[0].split(" ")[1]));
            slot.addProperty("hour", Integer.parseInt(Slot.fromSlotNumber(book.getSlot()).split(";")[1].split(":")[0].split(" ")[1]));

            mode.addProperty("mode", 0);

            reservation.addProperty("teaching", book.getTeaching().getId());
            reservation.add("slot", slot);

            elem.add("reservation", reservation);

            data.add("elem", elem);

            authorization.addProperty("email", this.mainUser.getUsername());
            authorization.addProperty("password", this.psw);

            jo.addProperty("type", "delete_done_reservation");
            jo.add("params", mode);
            jo.add("data", data);
            jo.add("authorization", authorization);
            Log.d("DONE", jo.toString());


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    JsonObject obj = gson.fromJson(response, JsonObject.class);
                    boolean error = obj.get("error").getAsBoolean();

                    if(!error) {
                        Toast.makeText(activity, "Reservation done.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(activity, "Error:" + obj.get("message"), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d("ERROR", error.toString());
                }
            }) {
                @Override
                public byte[] getBody() throws AuthFailureError {
                    return jo.toString().getBytes();
                }
            };

            queue.add(request);

        }

    }

    public void setPreferences(User user1, String password, String name, String surname, int role, String gender) {
        SharedPreferences.Editor editor = this.activity.sharedPreferences.edit();
        editor.putString("username", user1.getUsername());
        editor.putString("password", password);
        editor.putString("name", name);
        editor.putString("surname", surname);
        editor.putInt("role", role);
        editor.putString("gender", gender);

        psw = password;

        editor.commit();
    }

    public void modifiedCredential() {
        psw = "-1";
    }
}
