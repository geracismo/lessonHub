package com.example.lessonhub.controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.lessonhub.R;
import com.example.lessonhub.Session;
import com.example.lessonhub.model.Booking;
import com.example.lessonhub.model.Course;
import com.example.lessonhub.model.Professor;
import com.example.lessonhub.model.Teaching;
import com.example.lessonhub.model.User;
import com.example.lessonhub.view.Adapter;
import com.example.lessonhub.view.HistoryFragment;
import com.example.lessonhub.view.HomeFragment;
import com.example.lessonhub.view.LoginFragment;
import com.example.lessonhub.view.BookingFragment;
import com.example.lessonhub.view.ProfessorSpinnerAdapter;
import com.example.lessonhub.view.ReservationFragment;
import com.example.lessonhub.view.CourseSpinnerAdapter;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, LessonHubIntf {

    public FragmentManager fragmentMng;

    public HomeFragment homeFragment;

    public LoginFragment loginFragment;

    public ReservationFragment reservationFragment;

    public HistoryFragment historyFragment;

    public BookingFragment bookingFragment;

    public Session session;

    public SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        session = new Session(this);
        fragmentMng = getSupportFragmentManager();
        homeFragment = HomeFragment.newInstance();
        loginFragment = LoginFragment.newInstance();
        reservationFragment = ReservationFragment.newInstance();
        historyFragment = HistoryFragment.newInstance();
        bookingFragment = BookingFragment.newInstance();

        this.sharedPreferences = this.getSharedPreferences("com.example.lessonhub", Context.MODE_PRIVATE);

        String user = this.sharedPreferences.getString("username", "-1");
        String psw = this.sharedPreferences.getString("password", "-1");
        String name = this.sharedPreferences.getString("name", "-1");
        String surname = this.sharedPreferences.getString("surname", "-1");
        int c = this.sharedPreferences.getInt("role", -1);
        String gender = this.sharedPreferences.getString("gender", "-1");

        if (!user.equals("-1")) {
            this.session.mainUser = new User(user, name, surname, c, gender.charAt(0));
            this.session.psw = psw;
        } else {
            this.session.mainUser = null;
        }

        showFragment(homeFragment);
    }

    public void showFragment(Fragment fragment) {
        FragmentTransaction transaction = fragmentMng.beginTransaction().replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login_button:
                showFragment(loginFragment);
                break;
            case R.id.repetition_button:
                showFragment(bookingFragment);
                break;
            case R.id.history_button:
                showFragment(historyFragment);
                break;
            case R.id.reservation_button:
                showFragment(reservationFragment);
                break;
            case R.id.reserve_btn:
                List<Booking> requestBookings = new ArrayList<>();
                List<Booking> newDataSet = new ArrayList<>();

                Adapter adapter = (Adapter) bookingFragment.bookingList.getAdapter();

                for (int i = 0; i < adapter.bookings.size(); i++) {
                    Booking currentBook = (Booking) bookingFragment.bookingList.getItemAtPosition(i);
                    if (bookingFragment.bookingList.isItemChecked(i)) {
                        bookingFragment.bookingList.setItemChecked(i, false);
                        requestBookings.add(currentBook);
                        Log.d("Reserve", "requestBookings size = " + requestBookings.size());
                    } else {
                        newDataSet.add(currentBook);
                        Log.d("Reserve", "newDataSet size = " + newDataSet.size());
                    }
                }

                bookingFragment.professorSpinner.setSelection(0);
                bookingFragment.courseSpinner.setSelection(0);

                for (Booking book : requestBookings) {
                    adapter.bookings.remove(book);
                }

                adapter.notifyDataSetChanged();

                session.onBookReserve(requestBookings);
                break;

            case R.id.confirmed_btn:
                List<Booking> requestReservation = new ArrayList<>();
                List<Booking> newDataSet2 = new ArrayList<>();
                Adapter adapter2 = (Adapter) reservationFragment.reservationList.getAdapter();
                for (int i = 0; i < adapter2.getCount(); i++) {
                    if (reservationFragment.reservationList.isItemChecked(i)) {
                        reservationFragment.reservationList.setItemChecked(i, false);
                        requestReservation.add(adapter2.bookings.get(i));
                    } else
                        newDataSet2.add(adapter2.bookings.get(i));
                }

                adapter2.bookings = newDataSet2;
                adapter2.notifyDataSetChanged();

                this.session.onDoneReservation(requestReservation);

                break;
            case R.id.cenceled_btn:
                List<Booking> requestReservation2 = new ArrayList<>();
                List<Booking> newDataSet3 = new ArrayList<>();
                Adapter adapter3 = (Adapter) reservationFragment.reservationList.getAdapter();
                for (int i = 0; i < adapter3.getCount(); i++) {
                    if (reservationFragment.reservationList.isItemChecked(i)) {
                        reservationFragment.reservationList.setItemChecked(i, false);
                        requestReservation2.add(adapter3.bookings.get(i));
                    } else
                        newDataSet3.add(adapter3.bookings.get(i));
                }

                adapter3.bookings = newDataSet3;
                adapter3.notifyDataSetChanged();

                this.session.onCancelReservation(requestReservation2);

                break;

            case R.id.loginButton:
                TextInputEditText usr = findViewById(R.id.username);
                TextInputEditText psw = findViewById(R.id.password);

                String username = usr.getText().toString();
                String password = psw.getText().toString();

                this.session.onLogin(username, password);
                usr.getText().clear();
                psw.getText().clear();
                break;

            case R.id.logout_button:
                this.session.onLogout(this.session.mainUser.getUsername(), this.session.psw);
                sharedPreferences.edit().putString("username", "-1").commit();
                sharedPreferences.edit().putString("password", "-1").commit();
                session.modifiedCredential();
                homeFragment.loginBtn.setVisibility(View.VISIBLE);
                homeFragment.logoutBtn.setVisibility(View.GONE);
                homeFragment.historyBtn.setEnabled(false);
                homeFragment.reservationBtn.setEnabled(false);
                homeFragment.welcome.setText("Benvenuto");
                this.session.mainUser = null;
                break;

            case R.id.search:
                Adapter adapter5 = (Adapter) bookingFragment.bookingList.getAdapter();

                if(adapter5.bookings == null  || adapter5.bookings.isEmpty()) {
                    this.onFragmentViewCreated(bookingFragment);
                    break;
                }

                bookingFragment.bookingList.setVisibility(View.VISIBLE);
                List<Booking> list = new ArrayList<>();

                adapter5.normalize();

                Professor p = (Professor) bookingFragment.professorSpinner.getSelectedItem();
                Course c = (Course) bookingFragment.courseSpinner.getSelectedItem();

                for(Booking book : adapter5.bookings) {
                    if(p.getId() != -1 && c.getId() != -1) {
                        if(book.getTeaching().getProfessor().getId() == p.getId() &&
                                c.getId() == book.getTeaching().getCourse().getId())
                        {
                            list.add(book);
                        }
                    }else if(p.getId() == -1 && c.getId() != -1) {
                        if(c.getId() == book.getTeaching().getCourse().getId()) {
                            list.add(book);
                        }
                    } else if(p.getId() != -1 && c.getId() == -1) {
                        if( book.getTeaching().getProfessor().getId() == p.getId() ) {
                            list.add(book);
                        }
                    } else
                        list.add(book);
                }

                adapter5.bookings = list;
                adapter5.notifyDataSetChanged();
        }
    }


    @Override
    public void onFragmentViewCreated(Fragment fragment) {
        if (fragment == this.reservationFragment) {
            this.session.onLoadReservation();
        } else if (fragment == this.historyFragment) {
            this.session.onLoadHistory();
        } else if (fragment == this.bookingFragment) {
            this.session.onLoadProfessor();
            this.session.onLoadPossibleBooking();
            this.session.onLoadCourses();
            //this.bookingFragment.bookingList.setVisibility(View.GONE);
        }
    }
}