package com.example.lessonhub.view;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lessonhub.R;
import com.example.lessonhub.controller.MainActivity;

public class LoginFragment extends Fragment {

    MainActivity parent;

    Button button;

    public LoginFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login_fragment, container, false);
        button = view.findViewById(R.id.loginButton);
        button.setOnClickListener((View.OnClickListener) parent);
        return view;
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        parent = (MainActivity) context;
    }

    public static LoginFragment newInstance() {
        Bundle args = new Bundle();
        LoginFragment fragment = new LoginFragment();
        return fragment;
    }
}
