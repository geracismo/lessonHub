package com.example.lessonhub.view;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lessonhub.R;
import com.example.lessonhub.Session;
import com.example.lessonhub.controller.MainActivity;
import com.google.android.material.textfield.TextInputEditText;

public class HomeFragment extends Fragment {

    MainActivity parentActivity;

    public Button loginBtn;

    public Button repetitionBtn;

    public Button reservationBtn;

    public Button historyBtn;

    public Button logoutBtn;

    public TextView welcome;

    public HomeFragment() {


    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.home, container, false);

        repetitionBtn = (Button) view.findViewById(R.id.repetition_button);
        reservationBtn = (Button) view.findViewById(R.id.reservation_button);
        historyBtn = (Button) view.findViewById(R.id.history_button);
        loginBtn = (Button) view.findViewById(R.id.login_button);
        logoutBtn = (Button) view.findViewById(R.id.logout_button);
        welcome = (TextView) view.findViewById(R.id.welcome);


        repetitionBtn.setOnClickListener((View.OnClickListener) parentActivity);
        reservationBtn.setOnClickListener((View.OnClickListener) parentActivity);
        historyBtn.setOnClickListener((View.OnClickListener) parentActivity);
        loginBtn.setOnClickListener((View.OnClickListener) parentActivity);
        logoutBtn.setOnClickListener((View.OnClickListener) parentActivity);

        if(parentActivity.session.mainUser == null) {
            historyBtn.setEnabled(false);
            reservationBtn.setEnabled(false);
            welcome.setText("Benvenuto");
        }else{
            historyBtn.setEnabled(true);
            reservationBtn.setEnabled(true);
            logoutBtn.setVisibility(View.VISIBLE);
            loginBtn.setVisibility(View.GONE);
            welcome.setText("Benvenuto " + parentActivity.session.mainUser.getName());
        }

        return view;
    }

    public static HomeFragment newInstance() {
        Bundle args = new Bundle();
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        parentActivity = (MainActivity) context;
    }
}
