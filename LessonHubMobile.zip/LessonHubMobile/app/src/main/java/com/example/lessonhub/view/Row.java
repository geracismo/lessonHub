package com.example.lessonhub.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.example.lessonhub.R;

public class Row extends LinearLayout implements Checkable {
    private boolean checked = false;

    public Row(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void setChecked(boolean b) {
        this.checked = b;
        viewToggle(b);
    }

    @Override
    public boolean isChecked() {
        return this.checked;
    }

    @Override
    public void toggle() {
        this.checked = !this.checked;
        viewToggle(this.checked);
    }

    private void viewToggle(boolean b) {
        if(b) {
          this.findViewById(R.id.check).setVisibility(VISIBLE);
        } else {
            this.findViewById(R.id.check).setVisibility(GONE);
        }
    }
}
