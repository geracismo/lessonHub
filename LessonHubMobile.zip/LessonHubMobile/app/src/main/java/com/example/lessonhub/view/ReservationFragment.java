package com.example.lessonhub.view;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.lessonhub.R;
import com.example.lessonhub.controller.MainActivity;

public class ReservationFragment extends Fragment {

    public String TAG = "reservation";

    public ListView reservationList;

    public MainActivity parent;

    Button effectued;

    Button canceled;

    public ReservationFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.reservation_list, container, false);
        reservationList = view.findViewById(R.id.reservation_list);
        this.canceled = view.findViewById(R.id.cenceled_btn);
        this.effectued = view.findViewById(R.id.confirmed_btn);

        this.canceled.setOnClickListener((View.OnClickListener) parent);
        this.effectued.setOnClickListener((View.OnClickListener) parent);

        this.reservationList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        return view;
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        parent = (MainActivity) context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        parent.onFragmentViewCreated(this);
    }

    public static ReservationFragment newInstance() {
        ReservationFragment fragment = new ReservationFragment();
        return fragment;
    }

}
