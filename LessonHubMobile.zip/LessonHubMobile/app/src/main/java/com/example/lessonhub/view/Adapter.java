package com.example.lessonhub.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lessonhub.R;
import com.example.lessonhub.model.Booking;
import com.example.lessonhub.model.Course;
import com.example.lessonhub.model.Professor;
import com.example.lessonhub.model.Slot;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends BaseAdapter {
    public List<Booking> bookings;
    public List<Booking> display;


    private Context context;
    private String tag;


    public Adapter(Context context, List<Booking> bookings, String tag) {
        this.bookings = bookings;
        this.display = this.bookings;
        this.context = context;
        this.tag = tag;
    }

    @Override
    public int getCount() {
        return this.bookings.size();
    }

    @Override
    public Booking getItem(int position) {
        return bookings.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = LayoutInflater.from(context).inflate(R.layout.row, null);

        if(this.bookings == null)
            return view;

        if(this.tag.equals("history"))
            setHistoryVisibility(position, view, viewGroup);

        Booking book = (Booking) getItem(position);
        Professor professor = book.getTeaching().getProfessor();
        Course course = book.getTeaching().getCourse();
        int slot = book.getSlot();
        String day = Slot.fromSlotNumber(slot).split(";")[0].split(" ")[1];
        String hour = Slot.fromSlotNumber(slot).split(";")[1];

        TextView txt = view.findViewById(R.id.professor);
        txt.setText(professor.getName() + " " + professor.getSurname());

        txt = view.findViewById(R.id.course);
        txt.setText(course.getName());

        txt = view.findViewById(R.id.day);
        txt.setText(Slot.fromSlotNumber(slot).split(";")[0].split(" ")[0].substring(0, 3) + "\n" + day + "/12" );

        txt = view.findViewById(R.id.slot);
        txt.setText(hour);


        return view;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    public void normalize() {
        this.bookings = this.display;
    }


    private void setHistoryVisibility(int position, View view, ViewGroup viewGroup) {
        if(this.bookings.get(position).getStatus() == 0) {
            view.findViewById(R.id.canceled_text).setVisibility(View.GONE);
            view.findViewById(R.id.effectued_text).setVisibility(View.GONE);
            view.findViewById(R.id.active_text).setVisibility(View.VISIBLE);
        }else if(this.bookings.get(position).getStatus() == 1) {
            view.findViewById(R.id.canceled_text).setVisibility(View.GONE);
            view.findViewById(R.id.effectued_text).setVisibility(View.VISIBLE);
            view.findViewById(R.id.active_text).setVisibility(View.GONE);
        }else {
            view.findViewById(R.id.canceled_text).setVisibility(View.VISIBLE);
            view.findViewById(R.id.effectued_text).setVisibility(View.GONE);
            view.findViewById(R.id.active_text).setVisibility(View.GONE);
        }

    }
}
