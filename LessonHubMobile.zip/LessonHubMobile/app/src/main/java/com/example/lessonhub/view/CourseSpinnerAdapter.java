package com.example.lessonhub.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.lessonhub.R;
import com.example.lessonhub.model.Course;
import com.example.lessonhub.model.Professor;

import java.util.List;

public class CourseSpinnerAdapter extends BaseAdapter {

    public Context context = null;
    public List<Course> list = null;

    public CourseSpinnerAdapter(@NonNull Context context, List<Course> list) {
        this.context = context;
        this.list = list;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Course getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.spinner_row, null);

        Course c = (Course)getItem(position);
        TextView row = view.findViewById(R.id.spinner_row);

        if(c.getId() != -1) {
            row.setText((getItem(position)).getName());
        } else
            row.setText("");


        return view;
    }
}
