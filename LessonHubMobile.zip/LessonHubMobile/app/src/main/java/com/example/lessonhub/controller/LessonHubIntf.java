package com.example.lessonhub.controller;

import androidx.fragment.app.Fragment;

public interface LessonHubIntf {
    abstract void onFragmentViewCreated(Fragment fragment);
}
